package com.wallet.service;

public interface WalletService {

	static boolean validateEmployee(String acc) {
		// TODO Auto-generated method stub
		return false;
	}

	static int addEmployee(String acc) {
		// TODO Auto-generated method stub
		return 0;
	}


}
