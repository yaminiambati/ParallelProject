package com.wallet;

import java.util.Scanner;

import com.wallet.exception.WalletException;
import com.wallet.service.WalletService;

/**
 * Hello world!
 *
 */
public class App 
{
	Scanner scan = new Scanner(System.in);
	private String acc;
    public static void main( String[] args ) throws WalletException
    {
    	App c = new App();
		c.scan.useDelimiter("\n");
		String option = null;
		while(true) {
		System.out.println("==========Paytm Application==========");
		System.out.println("1. Create Account");
		System.out.println("2. Show Balance");
		System.out.println("3. Deposit");
		System.out.println("4. Withdraw");
		System.out.println("5. Fund Transfer");
		System.out.println("6. Print Transactions");
		option = c.scan.nextLine();
		switch(option) {
		case "1":
			c.addAccount();
			break;
		case "2":
			//c.getAllEmployee();
			break;
		case "3":
			//c.getEmployeeById();
			break;
		case "4":
			//c.deleteEmployee();
			break;
		case "5":
			break;
		case "6":
			System.exit(0);
		default:
			System.err.println("Invalid Option choose from 1 to 6");
			break;
		}
		}
    }
	private void addAccount() throws WalletException {
		// TODO Auto-generated method stub
		App app=new App();
		//System.out.println("Enter Employee Id");
		/*String id = scan.nextLine();
		int empId=Integer.parseInt(id);
		emp.setId(empId);*/
		//app.setId(Integer.parseInt(scan.nextLine()));
		System.out.println("Enter Customer Name");
		app.setname(scan.nextLine());
		System.out.println("Enter Mobile:");
		app.setmobile(scan.nextLine());
		System.out.println("Enter Email");
		app.setemail(scan.nextLine());
		boolean result = WalletService.validateEmployee(acc);
		if(result) {
			int ret = WalletService.addEmployee(acc);
			System.out.println("Employee with id"+ret+" added successfully");
		}
		
	}
	private void setemail(String nextLine) {
		// TODO Auto-generated method stub
		
	}
	private void setmobile(String nextLine) {
		// TODO Auto-generated method stub
		
	}
	private void setname(String nextLine) {
		// TODO Auto-generated method stub
		
	}
}
