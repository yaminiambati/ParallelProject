package com.wallet.dao;

import com.wallet.exception.WalletException;

public interface WalletDao {
	//int addAccount(Account acc) throws WalletException;
}
