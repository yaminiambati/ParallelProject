package com.wallet.dao;

import com.wallet.exception.WalletException;

public class WalletDaoImp implements WalletDao {
	
	public int addAccount() throws WalletException {
	}
	}
	

